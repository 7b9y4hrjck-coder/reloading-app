Reloading App Prototype v0.1

Open index.html on an iPhone or computer.
Features: dark UI, search, combined filters, sorting, detail view, persistent filters/scroll position, and 10 demo records.

IMPORTANT: demo specifications/prices are placeholders for UI testing, not verified production data.
